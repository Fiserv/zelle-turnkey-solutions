package com.mobile.dps.zelle.fiapp.zellefiapp

import android.content.Intent
import androidx.annotation.NonNull
import com.fiserv.dps.mobile.sdk.bridge.controller.Bridge.Companion.genericTag
import com.fiserv.dps.mobile.sdk.interfaces.GenericTag
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity: FlutterActivity(),GenericTag {
    private val CHANNEL = "zellesdk.launch"
    lateinit var zelleResult:MethodChannel.Result
    override fun configureFlutterEngine(@NonNull flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler {
                call, result ->
            if (call.method == "launchZelle") {
                genericTag = this
                val hashMap = call.arguments as HashMap<*,*>
                val  intent = Intent(this, LaunchZelle::class.java)
                intent.putExtra("data", hashMap)
                startActivity(intent)
            }
            this.zelleResult = result
        }
    }

    override fun getValue(name: String) {
        zelleResult.success(name)
    }

    override fun sessionTag(tag: String) {
        zelleResult.success(tag)
    }
}
