//
//  LaunchZelleViewController.swift
//  Runner
//
//  Created by GOWTHAM N on 20/07/22.
//

import UIKit
import ZelleSDK
class LaunchZelleViewController: UIViewController, GenericTagDelegate {
    func getValue(name: String) {
        print("\(name)")
    }

    
    var getData:NSDictionary?
    var flutterResult:FlutterResult?
    var appName:String? = ""
    var baseUrl:String? = ""
    var institutionId:String? = ""
    var product:String? = ""
    var fi_callback:Bool? = false
    var loaderData:NSDictionary? = NSDictionary()
    var ssoKey:String? = ""
    var parameters:NSDictionary? = NSDictionary()
    var callBack:String? = ""

    
    func sessionTag(name tag: String) {
        flutterResult!("\(tag)")
    }
    
    
    @IBOutlet weak var viewContainer: UIView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        Bridge.genericTag = self
        appName = getData?.value(forKey: "applicationName") as? String
        baseUrl = getData?.value(forKey: "baseUrl") as? String
        institutionId = getData?.value(forKey: "institutionId") as? String
        product = getData?.value(forKey: "product") as? String
        fi_callback = getData?.value(forKey: "fi_callback") as? Bool
        loaderData = getData?.value(forKey: "loaderData") as? NSDictionary
        ssoKey = getData?.value(forKey: "ssoKey") as? String
        parameters = getData?.value(forKey: "parameter") as? NSDictionary
        
         let zelle = Zelle(
            applicationName : appName,
            baseURL: baseUrl ?? "",
            institutionId: institutionId ?? "",
            product: product ?? "",
            ssoKey: ssoKey ?? "",
            fi_callback: fi_callback ?? false,
            loaderData: loaderData as! [String : String],
            parameters: parameters  as! [String : String]
        )

         lazy var bridge: Bridge = {
            Bridge(config: zelle,
                viewController: self
            )
        }()
        
        let zelleFrame = CGRect(x:0, y:0, width: view.frame.width, height: view.frame.height) //desired location
        let zelleView = bridge.view(frame: zelleFrame)
        
      //  let zelleView = bridge.popup(anchor: self.view)
        view.addSubview(zelleView)
    }
    

}
