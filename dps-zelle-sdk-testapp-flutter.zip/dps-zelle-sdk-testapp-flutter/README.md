# dps-zelle-sdk-testapp-flutter

## Zelle SDK Flutter Test App

To test the **latest** Android SDK and iOS framework file a test app was constructed using the Dart programming language.

Application name, base url, institution id, product, sso key, fi_callback, loaderData and appData are some of the input parameters. Below are some examples of data.

Application Name: Flutter FI App
Base URL : https://certtransfers.fta.cashedge.com/popnet/faces/loginServlet

Institution ID : 88850093

Product : zelle
SSO Key : 22caf86a16517740601e32f5e383a42b

## passing params from flutter(Dart) to native app to connect Zelle SDK

    Map<String, String> map = new HashMap();
    map['param1'] = "1234";
    map['param2'] = "something";
    map['param3'] = "abc123";
    
    Map<String, String> loaderData = new HashMap();
    loaderData['loaderColor'] = "hex color code";
    loaderData['bgColor'] = "hex color code";

    Map<String,Map<String, String>> pdData = new LinkedHashMap();
    //contact
    Map<String, String> contact_pd = new LinkedHashMap();
    contact_pd['title'] = 'CONTACT TITLE';
    contact_pd['message'] = 'CONTACT MESSAGE';

    //camera
    Map<String, String> camera_pd = new LinkedHashMap();
    camera_pd['title'] = 'CAMERA TITLE';
    camera_pd['message'] = 'CAMERA MESSAGE';

    //gallery
    Map<String, String> gallery_pd = new LinkedHashMap();
    gallery_pd['title'] = 'GALLERY TITLE';
    gallery_pd['message'] = 'GALLERY MESSAGE';

    pdData['pd_contact'] = contact_pd;
    pdData['pd_camera'] = camera_pd;
    pdData['pd_gallery'] = gallery_pd;

    void _lauchZelle() async{
      String zelleResult;
      try {
        final String result = await platform.invokeMethod('launchZelle',{
          'applicationName': _applicationNameController.text,
          'baseUrl':_baseUrlController.text,
          "institutionId":_institutionIdController.text,
          'product':_productController.text,
          'ssoKey': _ssoKeyController.text,
          'fi_callback': false,
	      'loaderData': loaderData,
          'appData': pdData,   //Optional
          'parameter':map});

        zelleResult = result as String;
        if(zelleResult.isNotEmpty){
          print('SessionTag-------------------${zelleResult}');
        }
      } on PlatformException catch (e) {
        zelleResult = "Failed to get result: '${e.message}'.";
      }
    }


## Note : Flutter FI should be used with latest SDK version.
