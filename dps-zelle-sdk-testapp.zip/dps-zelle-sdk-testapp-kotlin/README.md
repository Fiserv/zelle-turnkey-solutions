# dps-zelle-sdk-testapp-kotlin

## Zelle SDK Anroid Test App

To test the **latest** Android SDK, a test app was constructed using the Kotlin programming language.

Application name, base url, institution id, product, and sso key are some of the input parameters. Below are some examples of data.

Application Name: Demo Bank
Base URL : https://certtransfers.fta.cashedge.com/popnet/faces/loginServlet

Institution ID : 88850093

Product : zelle
SSO Key : 22caf86a16517740601e32f5e383a42b

## Kotlin to connect Zelle SDK

     val zelle = Zelle(
            applicationName = applicationName,
            institutionId = institutionId,
            ssoKey = sso,
            baseURL = baseUrl,
            product = product,
            parameters = mapOf(
                "param1" to "value1",
                "param2" to "value2",
                "param3" to "value3"
            )
        )

        val bridge: Bridge by lazy {
            Bridge(
                activity = activity as HomeActivity,
                config = zelle
            )
        }


## Note : Kotlin plugin should be used with latest SDK version.
