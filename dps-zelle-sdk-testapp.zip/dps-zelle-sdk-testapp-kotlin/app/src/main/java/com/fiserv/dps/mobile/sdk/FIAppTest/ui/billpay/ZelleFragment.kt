package com.fiserv.dps.mobile.sdk.FIAppTest.ui.billpay

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.fiserv.dps.mobile.sdk.FIAppTest.BuildConfig
import com.fiserv.dps.mobile.sdk.FIAppTest.R
import com.fiserv.dps.mobile.sdk.FIAppTest.databinding.FragmentZelleBinding
import com.fiserv.dps.mobile.sdk.bridge.controller.Bridge
import com.fiserv.dps.mobile.sdk.bridge.model.Zelle

class ZelleFragment : Fragment() {

    private var _binding: FragmentZelleBinding? = null

    private val binding get() = _binding!!


    private lateinit var viewModel: ZelleViewModel

    private  var terminatorAddress: String = ""
    private  var baseURL: String = ""
    private  var instId: String = ""
    private  var product: String = ""
    private  var ssoKey: String = ""

    companion object{
        fun newInstance(terminatorAddress: String, baseURL: String, instId: String, product: String, ssoKey:String) = ZelleFragment().apply {
            this.terminatorAddress = terminatorAddress
            this.baseURL = baseURL
            this.instId = instId
            this.product = product
            this.ssoKey = ssoKey
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding =  FragmentZelleBinding.inflate(inflater, container, false)
        return  binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        Log.d("zelleAct------------>","baseURL: $baseURL institutionId: $instId product: $product ssoKey: $ssoKey")

        val zelle = Zelle(
            applicationName = "RXP Application",
            baseURL = baseURL,
            institutionId = instId,
            product = product,
            ssoKey = ssoKey,
            fi_callback = false,
            loaderData = mapOf(
                "loaderColor" to "pass hex color code",
                "bgColor" to "pass hex color code"
            ),
            appData = null,
            parameters = null,

            )
        val bridge = Bridge(requireActivity(), zelle)
        zelle.preCacheContacts = true
        val view = bridge.view()
        requireActivity().supportFragmentManager.beginTransaction().replace(R.id.fragment_holder, view).commit()
    }



}