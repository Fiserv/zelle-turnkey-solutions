package com.fiserv.dps.mobile.sdk.FIAppTest

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.fiserv.dps.mobile.sdk.bridge.controller.Bridge
import com.fiserv.dps.mobile.sdk.bridge.model.Zelle
import kotlinx.android.synthetic.main.fragment_bill_pay.*

class ZelleActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_zelle)

        val baseUrl = intent.getStringExtra("baseURL").toString()
        val instId = intent.getStringExtra("instId").toString()
        val product = intent.getStringExtra("product").toString()
        val ssoKey = intent.getStringExtra("ssoKey").toString()

        Log.d("zelleAct------------>","baseURL: $baseUrl institutionId: $instId product: $product ssoKey: $ssoKey")

        val pdContact = mapOf(
            "title" to "Contact Title",
            "message" to "Contact Message")

        val pdCamera = mapOf(
            "title" to  "Camera Title",
            "message" to "Camera Message")


        val pdPhoto = mapOf(
            "title" to  "Photo Title",
            "message" to "Photo Message")

        val appData = mapOf(
            "pd_contact" to pdContact,
            "pd_camera" to pdCamera,
            "pd_gallery" to pdPhoto)


        val zelle = Zelle(
            applicationName = "RXP Application",
            baseURL = baseUrl,
            institutionId = instId,
            product = product,
            ssoKey = ssoKey,
            fi_callback = true,
            loaderData = mapOf(
                "loaderColor" to "pass hex color code",
                "bgColor" to "pass hex color code"
            ),
            appData = appData,
            parameters = null,
            )
        val bridge = Bridge(this, zelle)
        zelle.preCacheContacts = true
        val view = bridge.view()
        supportFragmentManager.beginTransaction().replace(R.id.fragment_holder, view).commit()
    }
}