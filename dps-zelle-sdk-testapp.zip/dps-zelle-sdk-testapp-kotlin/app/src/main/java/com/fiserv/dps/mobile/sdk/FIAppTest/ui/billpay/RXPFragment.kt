package com.fiserv.dps.mobile.sdk.FIAppTest.ui.billpay

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.*
import androidx.fragment.app.Fragment
import com.fiserv.dps.mobile.sdk.FIAppTest.HomeActivity
import com.fiserv.dps.mobile.sdk.FIAppTest.R
import com.fiserv.dps.mobile.sdk.FIAppTest.ZelleActivity
import com.fiserv.dps.mobile.sdk.FIAppTest.databinding.FragmentRXPBinding
import com.fiserv.dps.mobile.sdk.bridge.controller.Bridge
import com.fiserv.dps.mobile.sdk.bridge.model.Zelle
import kotlinx.android.synthetic.main.fragment_bill_pay.*


// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [RXPFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class RXPFragment : Fragment() {

    private var _binding: FragmentRXPBinding? = null

    private val binding get() = _binding!!

    private  var terminatorAddress: String =""

    companion object{
        fun newInstance(terminatorAddress: String) = RXPFragment().apply {
            this.terminatorAddress = terminatorAddress
        }
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        _binding =  FragmentRXPBinding.inflate(inflater, container, false)
        return  binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        //WebAppInterface.ipsAndroidInterface = this

        binding.edBaseUrl.setText("https://cw411-cert.checkfreeweb.com/imm/wps?rq=getlogin&sp=20414&iv=547269702d444553547269702d444553&showA2A=false&autoResume=Y&ticket=E3FFB0181AD5F2BA5FACDABE5C4FB612CBB23650839F83BC3CB1941B234BBDD74D0DA5F4E13104379A9F2C4726E1AB7E721587A8D126C74325DC012A089B8FE8&lang=en-us&container=webview_android&hasZelleSDK=true")

        binding.submit.setOnClickListener{
            loadWebView(binding.edBaseUrl.text.toString())
        }
    }

    override fun onResume() {
        super.onResume()
        binding.webView.visibility = View.GONE
        binding.inputView.visibility = View.VISIBLE
    }

    @SuppressLint("JavascriptInterface")
    private fun loadWebView(url: String) {

        binding.inputView.visibility = View.GONE
        binding.webView.visibility = View.VISIBLE

        binding.webView.run {

            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.cacheMode = WebSettings.LOAD_NO_CACHE

            addJavascriptInterface(this, "IPSAndroidInterface")

            addJavascriptInterface(
                WebAppInterface(this@RXPFragment, terminatorAddress),
                "IPSAndroidInterface"
            )
            webChromeClient = object : WebChromeClient() {
                override fun onJsAlert(
                    view: WebView?,
                    url: String?,
                    message: String?,
                    result: JsResult?
                ): Boolean {
                    return super.onJsAlert(view, url, message, result)
                }

                override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                    Log.d(
                        "console message from WebView",
                        "---------------->${consoleMessage?.message()}"
                    )
                    Log.d(
                        "console message from WebView",
                        "---------------->${consoleMessage?.lineNumber()}"
                    )
                    return super.onConsoleMessage(consoleMessage)
                }
            }
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    url: String?
                ): Boolean {

                    post { loadUrl(url!!.trim()) }
                    return true
                }


                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)

                }
            }


            Handler(Looper.getMainLooper()).postDelayed({
                Log.d(
                    "CompleteURL",
                    "----------------${url}"
                )
                post { loadUrl(url.trim()) }
            }, 1)
        }
    }

    /*override fun OpenZelleSDK(
        baseURL: String?,
        institutionId: String?,
        product: String?,
        ssoKey: String?
    ) {
        Log.d("values------------>","baseURL: $baseURL institutionId: $institutionId product: $product ssoKey: $ssoKey")

        if (baseURL != null && institutionId != null && product != null && ssoKey != null){
            val zelle = Zelle(
                applicationName = "RXP App",
                institutionId = institutionId,   //your institution Id
                ssoKey = ssoKey,
                baseURL = baseURL,               //your baseUrl
                product = product,
                loaderData = null,
                appData = null,
                parameters = mapOf(
                    "param1" to "value1",
                    "param2" to "value2",
                    "param3" to "value3"
                )
            )

            val bridge: Bridge by lazy {
                Bridge(
                    activity = activity as HomeActivity,
                    config = zelle
                )
            }

            zelle.preCacheContacts = true
            Handler(Looper.getMainLooper()).post(Runnable {
                binding.webView.visibility = View.GONE
                binding.fragmentHolder.visibility = View.VISIBLE
            })

            val view = bridge.view()
            activity?.supportFragmentManager?.beginTransaction()?.apply {
                 replace(R.id.fragment_holder, view)
                 commit()
            }
        }
    }*/

}

interface IPSAndroidInterface {

    fun OpenZelleSDK(
        baseURL: String?,
        institutionId: String?,
        product: String?,
        ssoKey: String?
    )
}

class WebAppInterface(fragment: Fragment, terminatorAddress: String) {

     var fragment: Fragment
     var terminatorAddress: String

    init {
        this.fragment = fragment
        this.terminatorAddress = terminatorAddress
    }

    companion object{
        lateinit var ipsAndroidInterface: IPSAndroidInterface
    }

    @JavascriptInterface
    fun IPSTimeOut() {
        //Parent app can perform action based on timeout
    }

    @JavascriptInterface
    fun OpenZelleSDK(
        baseURL: String?,
        institutionId: String?,
        product: String?,
        ssoKey: String?
    ){

        Log.d("values1------------>","baseURL: $baseURL institutionId: $institutionId product: $product ssoKey: $ssoKey")

       // ipsAndroidInterface.OpenZelleSDK(baseURL, institutionId, product, ssoKey)
       /* if (baseURL != null && institutionId != null && product != null && ssoKey != null){
            val newFragment = ZelleFragment.newInstance(terminatorAddress, baseURL, institutionId, product, ssoKey)
            val transaction = fragment.requireActivity().supportFragmentManager.beginTransaction()
            transaction.replace(R.id.nav_host_fragment_content_home, newFragment, newFragment::class.java.simpleName)
            transaction.addToBackStack(newFragment::class.java.simpleName)
        }*/

        val intent = Intent(fragment.context, ZelleActivity::class.java)
        intent.putExtra("baseURL", baseURL)
        intent.putExtra("instId", institutionId)
        intent.putExtra("product", product)
        intent.putExtra("ssoKey", ssoKey)
        fragment.context?.startActivity(intent)

    }
}

