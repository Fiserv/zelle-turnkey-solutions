package com.fiserv.dps.mobile.sdk.FIAppTest.ui.billpay

import androidx.lifecycle.ViewModel

class ZelleViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}