package com.fiserv.dps.mobile.sdk.FIAppTest.ui.billpay

import android.os.Bundle
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.fiserv.dps.mobile.sdk.FIAppTest.HomeActivity
import com.fiserv.dps.mobile.sdk.FIAppTest.R
import com.fiserv.dps.mobile.sdk.FIAppTest.databinding.FragmentBillPayBinding
import com.fiserv.dps.mobile.sdk.bridge.controller.Bridge
import com.fiserv.dps.mobile.sdk.bridge.controller.Bridge.Companion.genericTag
import com.fiserv.dps.mobile.sdk.bridge.model.Zelle
import com.fiserv.dps.mobile.sdk.interfaces.GenericTag
import kotlinx.android.synthetic.main.fragment_bill_pay.*

class BillPayFragment : Fragment(), GenericTag {

    private lateinit var billPayViewModel: BillPayViewModel
    private var _binding: FragmentBillPayBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        billPayViewModel =
            ViewModelProvider(this).get(BillPayViewModel::class.java)

        _binding = FragmentBillPayBinding.inflate(inflater, container, false)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        genericTag = this

        //ed_base_url.setText("https://dhayalu-fiserv.github.io/demo/index.html")

        submit.setOnClickListener {
            getData()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun getData() {
        if (TextUtils.isEmpty(ed_application_name.text.toString()))
            Toast.makeText(
                requireContext(),
                "Please provide the application name",
                Toast.LENGTH_LONG
            ).show()
        else if (TextUtils.isEmpty(ed_base_url.text.toString()))
            Toast.makeText(requireContext(), "Please provide the base URL", Toast.LENGTH_LONG)
                .show()
        else if (TextUtils.isEmpty(ed_institutionId.text.toString()))
            Toast.makeText(requireContext(), "Please provide the institution ID", Toast.LENGTH_LONG)
                .show()
        else if (TextUtils.isEmpty(ed_product.text.toString()))
            Toast.makeText(requireContext(), "Please provide the product name", Toast.LENGTH_LONG)
                .show()
        else if (TextUtils.isEmpty(ed_sso_key.text.toString()))
            Toast.makeText(requireContext(), "Please provide the sso key", Toast.LENGTH_LONG).show()
        else
            initiateView(
                ed_application_name.text.toString(),
                ed_sso_key.text.toString(),
                ed_institutionId.text.toString(),
                ed_base_url.text.toString(),
                ed_product.text.toString()
            )

    }

    /*private fun getSSO(payLoad:String, institutionId:String, baseUrl:String) {
        val appClient = AppClient()
        val apiInterface: ApiInterface = appClient.instance
        val call = apiInterface.getSSO(payLoad)
        call?.enqueue(object : Callback<String> {
            override fun onResponse(call: Call<String>, response: Response<String>) {
                if (response.isSuccessful) {
                    val res = response.body() as String
                        if(res != null) {
                            if(res.subSequence(0,3).equals("0||")) {
                                initiateView("",res.removePrefix("0||"), institutionId, baseUrl,"")
                                Log.d("sso key", "----------------------->${res}")
                            }else{
                                Log.d("sso key", "----------------------->Invalid Data")
                            }
                        }else{
                            Log.d("sso key", "----------------------->null")
                        }
                } else {

                    Toast.makeText(activity, "Invalid Response", Toast.LENGTH_LONG).show()
                }
            }

            override fun onFailure(call: Call<String>, t: Throwable) {
                Toast.makeText(activity, "Failure", Toast.LENGTH_LONG).show()
                Log.d("Cause", "----------------------->${t.message}")
                Log.d("Cause", "----------------------->${t.localizedMessage}")
                Log.d("Cause", "----------------------->${t}")
                Log.d("Cause", "----------------------->${call}")
            }
        })
    }*/

    private fun initiateView(
        applicationName: String,
        sso: String,
        institutionId: String,
        baseUrl: String,
        product: String
    ) {
        val pdContact = mapOf(
            "title" to "Contact Title",
            "message" to "Contact Message")

        val pdCamera = mapOf(
            "title" to  "Camera Title",
            "message" to "Camera Message")


        val pdPhoto = mapOf(
            "title" to  "Photo Title",
            "message" to "Photo Message")

        val appData = mapOf(
            "pd_contact" to pdContact,
            "pd_camera" to pdCamera,
            "pd_gallery" to pdPhoto)


        val zelle = Zelle(
            applicationName = applicationName,
            institutionId = institutionId,   //your institution Id
            ssoKey = sso,
            baseURL = baseUrl,               //your baseUrl
            product = product,
            fi_callback = true,
            loaderData = mapOf(
                "loaderColor" to ed_loader_color.text.toString(),
                "bgColor" to ed_bg_color.text.toString()
            ),
            appData = appData,
            parameters = mapOf(
                "param1" to "value1",
                "param2" to "value2",
                "param3" to "value3"
            )
        )

        val bridge: Bridge by lazy {
            Bridge(
                activity = requireActivity(),
                config = zelle
            )
        }

        zelle.preCacheContacts = true
        fragment_holder.visibility = View.VISIBLE
        view_input.visibility = View.GONE
        val view = bridge.view()
        activity?.supportFragmentManager?.beginTransaction()?.apply {
            replace(R.id.fragment_holder, view)
            commit()
        }

        /*val view = bridge.popup()
        view.show(supportFragmentManager, view.tag)*/
    }

    override fun getValue(name: String) {
        Toast.makeText(requireContext(), name, Toast.LENGTH_LONG).show()
    }


    override fun sessionTag(name: String) {
        Toast.makeText(requireContext(), name, Toast.LENGTH_LONG).show()
    }
}