package com.fiserv.dps.mobile.sdk.FIAppTest

import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Url

interface ApiInterface {
    @Headers("Content-Type: application/json")
    @GET
    fun getSSO(@Url url:String): retrofit2.Call<String>?
}