package com.fiserv.dps.mobile.sdk.FIAppTest.ui.billpay;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Toast;
import com.fiserv.dps.mobile.sdk.FIAppTest.R;
import com.fiserv.dps.mobile.sdk.bridge.controller.Bridge;
import com.fiserv.dps.mobile.sdk.bridge.model.Zelle;
import com.fiserv.dps.mobile.sdk.bridge.view.BridgeView;
import com.fiserv.dps.mobile.sdk.interfaces.GenericTag;

import java.util.HashMap;
import java.util.Map;


public class BillPayJavaFragment extends Fragment implements GenericTag {
    EditText applicationName;
    EditText baseUrl;
    EditText institutionId;
    EditText product;
    EditText ssoKey;
    Button submit;
    ConstraintLayout constraintLayout;
    FrameLayout frameLayout;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_bill_pay_java, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        applicationName = view.findViewById(R.id.ed_application_name);
        baseUrl = view.findViewById(R.id.ed_base_url);
        baseUrl.setText("https://certtransfers.fta.cashedge.com/popnet/faces/loginServlet");
        institutionId = view.findViewById(R.id.ed_institutionId);
        institutionId.setText("88851011");
        product = view.findViewById(R.id.ed_product);
        ssoKey = view.findViewById(R.id.ed_sso_key);
        ssoKey.setText("c0e72095f99096cb8d219af975021f81");
        submit = view.findViewById(R.id.submit);
        constraintLayout = view.findViewById(R.id.view_input);
        frameLayout = view.findViewById(R.id.fragment_holder);
        Bridge.genericTag = this;
        submit.setOnClickListener(view1 -> getData());

    }

    private void getData() {

        if (TextUtils.isEmpty(applicationName.getText().toString()))
            Toast.makeText(
                    requireContext(),
                    "Please provide the application name",
                    Toast.LENGTH_LONG
            ).show();
        else if (TextUtils.isEmpty(baseUrl.getText().toString()))
            Toast.makeText(requireContext(), "Please provide the base URL", Toast.LENGTH_LONG)
                    .show();
        else if (TextUtils.isEmpty(institutionId.getText().toString()))
            Toast.makeText(requireContext(), "Please provide the institution ID", Toast.LENGTH_LONG)
                    .show();
        else if (TextUtils.isEmpty(product.getText().toString()))
            Toast.makeText(requireContext(), "Please provide the product name", Toast.LENGTH_LONG)
                    .show();
        else if (TextUtils.isEmpty(ssoKey.getText().toString()))
            Toast.makeText(requireContext(), "Please provide the sso key", Toast.LENGTH_LONG).show();
        else
            initiateView(
                    applicationName.getText().toString(),
                    ssoKey.getText().toString(),
                    institutionId.getText().toString(),
                    baseUrl.getText().toString(),
                    product.getText().toString()
            );

    }

    private void initiateView(
            String applicationName,
            String ssoKey,
            String institutionId,
            String baseUrl,
            String product
    ) {

        constraintLayout.setVisibility(View.GONE);
        frameLayout.setVisibility(View.VISIBLE);

        Map<String,String> paramMap= new HashMap<>();
        paramMap.put("param1","1234");
        paramMap.put("param2","something");
        paramMap.put("param3","abc123");

        Map<String,String> loaderData= new HashMap<>();
        loaderData.put("loaderColor","pass hex color code");
        loaderData.put("bgColor","pass hex color code");

        Map<String,String> pdContact= new HashMap<>();
        pdContact.put("title","Contact Title");
        pdContact.put("message","Contact Message");

        Map<String,String> pdCamera= new HashMap<>();
        pdCamera.put("title","Camera Title");
        pdCamera.put("message","Camera Message");


        Map<String,String> pdPhoto= new HashMap<>();
        pdPhoto.put("title","Photo Title");
        pdPhoto.put("message","Photo Message");

        Map<String, Map<String,String>> appData = new HashMap<>();
        appData.put("pd_contact", pdContact);
        appData.put("pd_camera",  pdCamera);
        appData.put("pd_gallery", pdPhoto);

        Zelle zelle = new Zelle(
                applicationName,    //optional
                baseUrl,            //your baseUrl
                institutionId,      //your institution Id
                product,
                ssoKey,//you ssoKey
                true, //If you could not handled getTag method send it as false else true
                loaderData,
                appData,            //optional
                paramMap            //optional
        );

        Bridge bridge = new Bridge(requireActivity(), zelle);
        zelle.setPreCacheContacts(true);
        BridgeView view = bridge.view();
        requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragment_holder, view).commit();

        //To handle PopupView
        /*BridgePopup popup = bridge.popup();
        view.show(requireActivity().getSupportFragmentManager(), view.getTag())*/
    }

    @Override
    public void sessionTag(@NonNull String s) {
        Toast.makeText(requireContext(), s, Toast.LENGTH_LONG).show();
    }

    @Override
    public void getValue(@NonNull String s) {
        Toast.makeText(requireContext(), s, Toast.LENGTH_LONG).show();
    }
}