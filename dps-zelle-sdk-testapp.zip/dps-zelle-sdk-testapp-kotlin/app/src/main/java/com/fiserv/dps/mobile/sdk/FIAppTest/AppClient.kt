package com.fiserv.dps.mobile.sdk.FIAppTest

import com.google.gson.GsonBuilder
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Response
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.converter.scalars.ScalarsConverterFactory
import java.net.HttpURLConnection
import java.util.concurrent.TimeUnit

class AppClient {

    private val BASE_URL = "https://qa.ft.cashedge.com/"

    val gson = GsonBuilder()
        .setLenient()
        .create()


    private fun getClient(): OkHttpClient {
        val loggingInterceptor = HttpLoggingInterceptor()
        loggingInterceptor.level = HttpLoggingInterceptor.Level.BODY
        val client: OkHttpClient?
        client = OkHttpClient.Builder()
            .addNetworkInterceptor(object : Interceptor {

                private val FOLLOW_REDIRECT = "follow-redirect"
                val FOLLOW_HEADER = "$FOLLOW_REDIRECT:true"
                private val LOCATION = "Location"

                override fun intercept(chain: Interceptor.Chain): Response {

                    var request = chain.request()
                    val shouldRedirect = request.header(FOLLOW_REDIRECT) != null
                    if (shouldRedirect) {
                        request = request.newBuilder().removeHeader(FOLLOW_REDIRECT).build()
                    }
                    val response = chain.proceed(request)
                    return if (response.code() == HttpURLConnection.HTTP_CREATED && response.header(LOCATION) != null) {
                        response.newBuilder().code(HttpURLConnection.HTTP_SEE_OTHER).build()
                    } else response
                }

            })
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
        return client
    }

    val instance: ApiInterface by lazy{
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create(gson))
            .addConverterFactory(ScalarsConverterFactory.create())
            .client(getClient())
            .build()

        retrofit.create(ApiInterface::class.java)
    }

}