package com.fiserv.dps.mobile.sdk.FIAppTest.ui.billpay

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class BillPayViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "Bill Pay"
    }
    val text: LiveData<String> = _text
}