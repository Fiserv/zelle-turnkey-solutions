//
//  HomeViewController.swift
//  DemoNavDrawer
//
//  Created by Datanautic on 03/09/21.
//  Copyright © 2021 sivakumar. All rights reserved.
//

import UIKit
import ZelleSDK
class HomeViewController: UIViewController,SidebarViewDelegate {
   
var sidebarView: SidebarView!
var blackScreen: UIView!
    
override func viewDidLoad() {
    super.viewDidLoad()

    self.navigationController?.navigationBar.barTintColor = UIColor(red: 141.0/255.0, green: 191.0/255.0, blue: 78.0/255.0, alpha: 1.0)
    self.title = "Demo Bank"
}

override func viewWillAppear(_ animated: Bool){
   self.navigationController?.isNavigationBarHidden = false
   self.navigationController?.interactivePopGestureRecognizer?.isEnabled = false
    self.navigationItem.hidesBackButton = true
   let btnMenu = UIBarButtonItem(image:UIImage(named:"02MenuIcon.png"), style: .plain, target: self, action: #selector(btnMenuAction))
       self.navigationItem.leftBarButtonItem = btnMenu
   sidebarView=SidebarView(frame: CGRect(x: 0, y: 0, width: 0, height:self.view.frame.height))
   
   sidebarView.delegate = self as? SidebarViewDelegate
   
       sidebarView.layer.zPosition=100
       self.view.isUserInteractionEnabled=true
       self.navigationController?.view.addSubview(sidebarView)
          
       blackScreen=UIView(frame: self.view.bounds)
       blackScreen.backgroundColor=UIColor(white: 0, alpha: 0.5)
       blackScreen.isHidden=true
       self.navigationController?.view.addSubview(blackScreen)
       blackScreen.layer.zPosition=99
       let tapGestRecognizer = UITapGestureRecognizer(target: self, action: #selector(blackScreenTapAction(sender:)))
       blackScreen.addGestureRecognizer(tapGestRecognizer)
}
     
@objc func btnMenuAction(){
   blackScreen.isHidden=false
   UIView.animate(withDuration: 0.3, animations: {
    self.sidebarView.frame=CGRect(x: 0, y: 0, width:(self.view.window?.frame.width)!-80, height: self.sidebarView.frame.height)
   }) { (complete) in
       self.blackScreen.frame=CGRect(x: self.sidebarView.frame.width, y: 0, width: self.view.frame.width-self.sidebarView.frame.width, height: self.view.bounds.height+100)
   }
}
       
@objc func blackScreenTapAction(sender: UITapGestureRecognizer) {
   blackScreen.isHidden=true
   blackScreen.frame=self.view.bounds
   UIView.animate(withDuration: 0.3) {
       self.sidebarView.frame=CGRect(x: 0, y: 0, width: 0, height: self.sidebarView.frame.height)
   }
}
func paySectionClicked(row:Row) {

blackScreen.isHidden=true
         blackScreen.frame=self.view.bounds
         UIView.animate(withDuration: 0.3) {
             self.sidebarView?.frame=CGRect(x: 0, y: 0, width: 0, height: (self.sidebarView?.frame.height)!)
         }
     switch row {
     case .ZELLE:

  //  self.customButtons()
             print("Zell UI")

         guard let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "PayLoadViewController") as? PayLoadViewController else {
                     return
                 }
             self.navigationController?.pushViewController(vc, animated: false)
         
         
        // let vc:HomeViewController = HomeViewController()
     
     case .RXP:
         
         guard let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "RXPLoginViewController") as? RXPLoginViewController else {
                     return
                 }
        self.navigationController?.pushViewController(vc, animated: false)
         
     case .FiservTurnKey: break
     case .TransferNow: break
     case .Profile: break
     case .Deposits: break
        
}
}
}
