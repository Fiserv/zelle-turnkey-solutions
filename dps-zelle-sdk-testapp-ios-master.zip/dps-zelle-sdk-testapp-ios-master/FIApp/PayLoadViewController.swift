//
//  PayLoadViewController.swift
//  FIApp
//
//  Created by Jayant Tiwari on 26/09/21.
//  Copyright © 2021 Fiserv. All rights reserved.
//
import UIKit

class PayLoadViewController: UIViewController {
    
    @IBOutlet weak var txtPayload: UITextField!
    @IBOutlet weak var baseUrlTF:UITextField!
    @IBOutlet weak var institutionTF: UITextField!
    @IBOutlet weak var zellTF: UITextField!
    @IBOutlet weak var ssoTF: UITextField!
    
    @IBOutlet weak var loaderColorTF: UITextField!
    
    @IBOutlet weak var bgColorTF: UITextField!


    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationController?.navigationBar.barTintColor = UIColor(red: 141.0/255.0, green: 191.0/255.0, blue: 78.0/255.0, alpha: 1.0)
        self.title = "Demo Bank"
    }
    
    deinit {
        print("Deinit payload called")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        //txtPayload.textColor = .blue
      
       //
        txtPayload.attributedPlaceholder = NSAttributedString(
            string: "Enter Application Name",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray]
        )
        
        zellTF.attributedPlaceholder = NSAttributedString(
            string: "Enter Product",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray]
        )
        
        
        ssoTF.attributedPlaceholder = NSAttributedString(
            string: "Enter SSO Key",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray]
        )
        baseUrlTF.attributedPlaceholder = NSAttributedString(
            string: "Enter Base Url",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray]
        )
        institutionTF.attributedPlaceholder = NSAttributedString(
            string: "Enter Institition Id",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray]
        )
        
        loaderColorTF.attributedPlaceholder = NSAttributedString(
            string: "Enter Loader Color",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray]
        )
        
        bgColorTF.attributedPlaceholder = NSAttributedString(
            string: "Enter bg Color",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray]
        )
    }
    
    // listener
    @IBAction func btnSubmitClicked(_ sender: Any) {
        
       // var txtUrl = txtPayload.text!
            
        if baseUrlTF.text != "" && institutionTF.text != "" &&  ssoTF.text != "" && zellTF.text != "" {
            
            DispatchQueue.main.async {
            guard let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "ZelleViewController") as? ZelleViewController else {
                    return
            }
                vc.ssokKey = self.ssoTF.text!
                vc.appname = self.txtPayload.text!
                vc.product  = self.zellTF.text!
                vc.baseUrl =  self.baseUrlTF.text!
                vc.institutionId = self.institutionTF.text!
                vc.loaderColor = self.loaderColorTF.text!
                vc.bgColor = self.bgColorTF.text!
                
            self.navigationController?.pushViewController(vc, animated: false)
        }
        } else {
            Util.showToast(view: self.view, message: "Pls enter values in all the fields.", font: .systemFont(ofSize: 12.0))
        }

        //                }
//            } else {
//
//                let configDefault = URLSessionConfiguration.ephemeral
//                let sessionDefault = URLSession(configuration: configDefault)
//                let defaultUrl = URL(string: Constants.PAYLOAD_URL)!
//
//                let taskDefault = sessionDefault.dataTask(with: defaultUrl) { data, response, error in
//
//                guard let data = data, error == nil else {
//                    print("\(error)")
//                    return
//                }
//                let string = String(data: data, encoding: .utf8)!
//
//                    let result:[String] =  string.components(separatedBy: " ").filter({ $0.range(of: "0||") != nil })
//                    var ssoKey = result[0][3...].components(separatedBy: .whitespacesAndNewlines).joined()
//                    print("else Response SSO \(ssoKey)")
//                    Constants.SSO_KEY = ssoKey
//                    print("else SSO \(Constants.SSO_KEY)")
//                    DispatchQueue.main.async {
//                        guard let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "ZelleViewController") as? ZelleViewController else {
//                                return
//                        }
//                        self.navigationController?.pushViewController(vc, animated: false)
//                    }
//                }
//                taskDefault.resume()
//            }
//
//        }
//        taskMain.resume()
        
//            let url = URL(string: payLoadurl)!
//            let task = URLSession.shared.dataTask(with: url) { data, response, error in
//                guard let data = data, error == nil else {
//                    print("\(error)")
//                    return
//                }
//                let string = String(data: data, encoding: .utf8)!
//                if (string.contains("0||")) {
//                    let result:[String] =  string.components(separatedBy: " ").filter({ $0.range(of: "0||") != nil })
//                    var ssoKey = result[0][3...]
//                    Constants.SSO_KEY = ssoKey
//                    print("if Response SSO \(ssoKey)")
//                    print("if SSO \(Constants.SSO_KEY)")
//                    DispatchQueue.main.async {
//                        guard let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "ZelleViewController") as? ZelleViewController else {
//                                return
//                        }
//                        self.navigationController?.pushViewController(vc, animated: false)
//                    }
//                }
//
//                else {
//
//                    let defaultUrl = URL(string: Constants.PAYLOAD_URL)!
//                    let task = URLSession.shared.dataTask(with: defaultUrl) { data, response, error in
//                    guard let data = data, error == nil else {
//                        print("\(error)")
//                        return
//                    }
//                        let string = String(data: data, encoding: .utf8)!
//                        let result:[String] =  string.components(separatedBy: " ").filter({ $0.range(of: "0||") != nil })
//                        var ssoKey = result[0][3...]
//                        print("else Response SSO \(ssoKey)")
//                        Constants.SSO_KEY = ssoKey
//                        print("else SSO \(Constants.SSO_KEY)")
//                        DispatchQueue.main.async {
//                            guard let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "ZelleViewController") as? ZelleViewController else {
//                                    return
//                            }
//                            self.navigationController?.pushViewController(vc, animated: false)
//                        }
//                    }
//                    task.resume()
//                }
//            }
//            task.resume()
    }
}


