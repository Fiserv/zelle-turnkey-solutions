//
//  RXPLoginViewController.swift
//  FIApp
//
//  Created by Jayant Tiwari on 11/04/23.
//  Copyright © 2023 Fiserv. All rights reserved.
//

import UIKit

class RXPLoginViewController: UIViewController {
    
    @IBOutlet weak var txtRXPUrl: UITextField!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnSubmitClicked(_ sender: Any) {
        
        if txtRXPUrl.text != "" {
            
        guard let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "RXPLandingViewController") as? RXPLandingViewController else {
                    return
                }
            
        vc.RXP_URL = self.txtRXPUrl.text!
       self.navigationController?.pushViewController(vc, animated: false)
        }
        else {
            Util.showToast(view: self.view, message: "Please enter RXP Url.", font: .systemFont(ofSize: 12.0))
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
