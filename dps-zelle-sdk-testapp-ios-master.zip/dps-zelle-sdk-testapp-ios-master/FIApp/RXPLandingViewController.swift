//
//  RXPLandingViewController.swift
//  FIApp
//
//  Created by Jayant Tiwari on 11/04/23.
//  Copyright © 2023 Fiserv. All rights reserved.
//

import UIKit
import WebKit
import ZelleSDK


class RXPLandingViewController: UIViewController, WKNavigationDelegate {
    
    var  RXP_URL : String = ""
    
    @IBOutlet weak var webView: WKWebView!
    
    
    @IBOutlet weak var viewContainer: UIView!
    
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        webView.load(URLRequest(url: URL(string: RXP_URL)!))
        
        webView.navigationDelegate = self
        
      //  webView!.load(URLRequest(url: URL(string: url)!))

        // Do any additional setup after loading the view.
    }
    
    // WKNavigationDelegate method
    
    public func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        
        var KEY : String = "PSiOSInterface://OpenZelleSDK?"
        
        if let urlStr = navigationAction.request.url?.absoluteString {
            
            if (urlStr.lowercased().contains(KEY.lowercased())) {
                
            print("Match Found")
            var updatedURL: String = (navigationAction.request.url?.absoluteString.replacingOccurrences(of: "unsafe:", with: ""))!
            var params : String = updatedURL.replacingOccurrences(of: "IPSiOSInterface://OpenZelleSDK?", with: "")
            params = params.replacingOccurrences(of: "+", with: "").removingPercentEncoding!
                
            var baseURL = ""
            var institutionId = ""
            var product = ""
            var ssoKey = ""
            
            let values  = params.components(separatedBy: "|")
                
            if(values != nil && values.count == 8) {
                for i in 0..<values.count {
                    
                    if ("baseURL" == values[i]) {
                    baseURL = values[i+1]
                    }
                    if ("institutionId" == values[i]) {
                    institutionId = values[i+1]
                    }
                    if ("product" == values[i]) {
                    product = values[i+1]
                    }
                    if ("ssoKey" == values[i]) {
                    ssoKey = values[i+1]
                    }
                }
                
                baseURL  = baseURL.replacingOccurrences(of: "http//", with: "http://")
                baseURL  = baseURL.replacingOccurrences(of: "https//", with: "https://")
                
                print("baseURL : \(baseURL)")
                print("institutionId : \(institutionId)")
                print("product : \(product)")
                print("ssoKey : \(ssoKey)")
                
                
                DispatchQueue.main.async {
                guard let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "ZelleViewController") as? ZelleViewController else {
                        return
                }
                    
                    vc.baseUrl =  baseURL
                    vc.institutionId = institutionId
                    vc.product  = product
                    vc.ssokKey = ssoKey
                    
                self.navigationController?.pushViewController(vc, animated: false)
            }
                
                
//                var zelle = Zelle(applicationName: "RXP Demo", baseURL: baseURL, institutionId: institutionId, product: product, ssoKey: ssoKey, fi_callback: true,
//                      loaderData: [
//                            "loaderColor" : "#FFFFFF",
//                            "bgColor" : "#747474"
//                        ],
//                      parameters: [
//                      "key1" : "value1",
//                      "key2" : "value2",
//                      "key3" : "value3",
//                  ]
//              )
//
//                let bridge: Bridge = {
//                    Bridge(
//                        config: zelle,
//                        viewController: self
//                    )
//                }()
                
//                let zelleFrame = CGRect(x:0, y:0, width:viewContainer.frame.width, height:viewContainer.frame.height) //desired location
//                  let zelleView = bridge.view(frame: zelleFrame)
//                  view.addSubview(zelleView)
                
//                Bridge.genericTag = self
//                webView.isHidden = true

            }
                
            } else {
                
                print("Error Found")
            }
        }
        decisionHandler(.allow)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
