//
//  Constants.swift
//  FIApp
//
//  Created by Jayant Tiwari on 26/09/21.
//  Copyright © 2021 Fiserv. All rights reserved.
//
import Foundation

struct Constants {
    

static var FINAL_URL : String? = ""
    
}
