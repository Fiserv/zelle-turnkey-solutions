//
//  ViewController.swift
//  FIApp
//
//  Created by Jayant Tiwari on 29/06/21.
//  Copyright © 2021 Fiserv. All rights reserved.
//
import UIKit
import ZelleSDK


class ZelleViewController: UIViewController, GenericTagDelegate {
    
    @IBOutlet weak var viewContainer: UIView!

    @IBOutlet weak var footerView: UIView!
    
    
    var zelle:Zelle? = nil

    var  ssokKey:String = ""
    var appname:String  = ""
    
    var  baseUrl:String = ""
    var institutionId:String = ""
    var product:String = ""
    
    var bgColor:String = ""
    var loaderColor:String = ""
  
    // Constructed Url
   
    override func viewDidLoad() {
        super.viewDidLoad()
       // self.title = "Demo Bank"
        
        if appname == "" {
            
            zelle = Zelle(baseURL: baseUrl, institutionId: institutionId, product: product, ssoKey: ssokKey, fi_callback: true,
                  loaderData: [
                        "loaderColor" : loaderColor,
                        "bgColor" : bgColor
                    ],
                  parameters: [
                  "key1" : "value1",
                  "key2" : "value2",
                  "key3" : "value3",
              ]
          )

//            zelle = Zelle(
//               baseURL: baseUrl,
//               institutionId:institutionId,
//               product: product,
//               ssoKey: ssokKey,
//               parameters: [
//                   "fi_callback" : "value1",
//                   "key2" : "value2",
//                   "key3" : "value3",
//               ]
//           )
            
        }else{
            
            zelle = Zelle(applicationName: appname, baseURL: baseUrl, institutionId: institutionId, product: product, ssoKey: ssokKey, fi_callback: true, loaderData: [
                "loaderColor" : loaderColor,
                "bgColor" : bgColor
            ])
         
//            zelle = Zelle(
//            applicationName: appname,
//            baseURL: baseUrl,
//            institutionId:institutionId,
//            product: product,
//            ssoKey: ssokKey
//        )
            
        }
        
        let bridge: Bridge = {
            Bridge(
                config: zelle!,
                viewController: self
            )
        }()
        
        // Default flow with Frame
        
        print("FI Frame Width \(String(describing: viewContainer.frame.width))")
        print("FI Frame Height \(String(describing: viewContainer.frame.height))")
        
        let zelleFrame = CGRect(x:0, y:0, width:viewContainer.frame.width, height:viewContainer.frame.height) //desired location
        
        // Supports only Portratit mode
        
          let zelleView = bridge.view(frame: zelleFrame)
          view.addSubview(zelleView)
          view.addSubview(footerView)
        
        // Initialize the ZelleView with fill
        
//        let zelleView = bridge.view()
//        zelleView.fill(view)
//        view.addSubview(footerView)
        
        Bridge.genericTag = self
        
        // Initialize the ZellePopup
        
//        let zellePopup = bridge.popup()
//        zellePopup.anchor(to: view)
    }
   
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
    }
    
    deinit {
        print("Deinit zelle called")
    }
    

    func sessionTag(name: String) {
        print("Tag Name :\(name)")
        
        let alertController = UIAlertController(title: nil, message: "sessionTag Called", preferredStyle: .alert)

           alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action) in
               
           }))

        self.present(alertController, animated: true, completion: nil)
        self.navigationController?.popViewController(animated: true)
    }
    
    func getValue(name: String) {
        print("Zelle Tag Name :\(name)")
        
        let alertController = UIAlertController(title: nil, message: "getZelleTag Called", preferredStyle: .alert)

           alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action) in
               
           }))

        self.present(alertController, animated: true, completion: nil)
    }
    
    func onFailureLogs(errorMsg: String) {
        print("Error: \(errorMsg)")
    }
}
