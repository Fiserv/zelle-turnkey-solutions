//
//  ViewController.m
//  ObjectiveCFIAPP
//
//  Created by Jayant Tiwari on 4/08/22.
//

#import "ViewController.h"
#import <ZelleSDK/ZelleSDK.h>


@interface ViewController ()<GenericTagDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
    Zelle *zelle = [[Zelle alloc] initWithApplicationName:@"Test App" baseURL:@"Enter the base url" institutionId: @"Enter the homeId" product:@"Zelle" ssoKey:@"Enter the SSOKey generated from payload url" fi_callback:nil loaderData:nil parameters:nil];
    
    NSLog(@"Zelle Url  %@", zelle.url);
    
    
//    Zelle* zelle = [[Zelle alloc]initWithApplicationName:@"YOUR_APPLICATION_NAME" baseURL:@"YOUR_BASE_URL" institutionId:@"YOUR_INSTITUTION_ID" product:@"zelle" ssoKey:@"YOUR_SSO_KEY" parameters:nil];
    
    Bridge* bridge = [[Bridge alloc] initWithConfig:zelle viewController:self ];
    
    //Launch Zelle® inside another view using code initialization
        
    CGRect zelleFrame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
    UIView* zelleView = [bridge viewWithFrame:zelleFrame];
    [self.view addSubview:zelleView];
    
  //  Launch Zelle inside another view and filling it to support screen orientation
    /*
    BridgeView* bridgeView = [bridge view];
    [bridgeView fill:self.view];
          */
    
   // Launch Zelle® as a popup (not inside another view)
    /*
    BridgePopup* bridgePopup = [bridge popup];
    [bridgePopup anchorTo:self.view];
    */
    
    Bridge.genericTag = self;
}

// Used for handling session timeout
- (void)sessionTagWithName:(NSString *)name {
    NSLog(@"Tag Name %@", name);
}

// Used for interceptiong web links
- (void)getValueWithName:(NSString *)name {
    
    NSLog(@"Tag Name %@", name);
}

@end
