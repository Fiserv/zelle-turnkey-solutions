//
//  SceneDelegate.h
//  ObjectiveCFIAPP
//
//  Created by Jayant Tiwari on 4/08/22.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

