# dps-zelle-sdk-testapp-reactnative

## Zelle SDK React Native Test App

To test the **latest** Android SDK and iOS framework file a test app was constructed using the java script, Android(java, kotlin) and iOS(Objective-C, swift) programming language.

Application name, base url, institution id, product, sso key, fi_callback, loaderData and appData and parameters are some of the input datas. 

## React Native to connect Native code (Android/iOS)
NativeModules.MyModule.NavigateToZelle(this.state.appname, this.state.baseurl, this.state.institutionid, this.state.product, this.state.ssokey, fi_callback, loaderData, parameter, pd);


## Note : React Native FI should be used with latest SDK version.
