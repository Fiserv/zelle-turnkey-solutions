//
//  MyModule.swift
//  ReactDemo
//
//  Created by Saravanan Saraz on 16/08/22.
//

import Foundation
import UIKit
import ZelleSDK
import UIKit
import React

@objc(MyModule)
class MyModule: RCTEventEmitter, GenericTagDelegate{
  
  override static func requiresMainQueueSetup() -> Bool {
    return true
  }
  
  override func supportedEvents() -> [String]! {
    return ["sessionTimeout","getValue"]
  }
  
  @objc func NavigateToZelle(_ appName: String, baseUrl: String, instId: String, product: String, ssoKey:String, fi_callback: Bool, loaderData: NSDictionary,parameters: NSDictionary, pd: NSDictionary){
    Bridge.genericTag = self
    
    
    NSLog("appname %@  baseUrl %@", parameters, pd);
    
  
    DispatchQueue.main.async {
  
      let storyboard = UIStoryboard(name: "main", bundle: nil)
      let secondVC: ZelleViewController = storyboard.instantiateViewController(withIdentifier: "ZelleViewController") as! ZelleViewController
      secondVC.applicationName = appName
      secondVC.baseUrl = baseUrl
      secondVC.institutionId = instId
      secondVC.product = product
      secondVC.ssoKey = ssoKey
      secondVC.fi_callback = fi_callback
      secondVC.loaderData = loaderData
      secondVC.parameters = parameters
       UIApplication.shared.keyWindow?.rootViewController?.present(secondVC, animated: true, completion: nil)
    }

  }
  
  func sessionTag(name: String) {
    print("session data "+name)
    if(name != ""){
      self.sendEvent(withName: "sessionTimeout", body: ["data":name])
    }
  }
  
  func getValue(name: String) {
    print("get data "+name)
    if(name != ""){
      self.sendEvent(withName: "getValue", body: ["data":name])
    }
  }

}
