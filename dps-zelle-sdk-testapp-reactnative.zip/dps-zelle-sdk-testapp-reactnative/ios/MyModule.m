//
//  MyModule.m
//  ReactDemo
//
//  Created by Saravanan Saraz on 16/08/22.
//

#import <Foundation/Foundation.h>
#import "React/RCTBridgeModule.h"

@interface RCT_EXTERN_MODULE(MyModule, NSObject)

RCT_EXTERN_METHOD(NavigateToZelle: (NSString *)appName baseUrl:(NSString *)baseUrl instId:(NSString *)instId product:(NSString *)product ssoKey:(NSString *)ssoKey fi_callback:(BOOL *)fi_callback loaderData:(NSDictionary *)loaderData parameters:(NSDictionary *)parameters pd:(NSDictionary *)pd)


@end
