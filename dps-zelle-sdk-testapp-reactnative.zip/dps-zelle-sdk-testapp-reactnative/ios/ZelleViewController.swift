//
//  ZelleViewController.swift
//  ReactDemo
//
//  Created by Saravanan Saraz on 16/08/22.
//

import UIKit
import ZelleSDK

class ZelleViewController: UIViewController {
  
  
  @IBOutlet weak var viewContainer: UIView!
  var applicationName = ""
  var baseUrl = ""
  var institutionId = ""
  var product = ""
  var ssoKey = ""
  var fi_callback = false
  var loaderData: NSDictionary?
  var parameters: NSDictionary?
  var dd = "https://jayjt11.github.io/Sdk/index.html"

    override func viewDidLoad() {
        super.viewDidLoad()
      print("comming inside of view controller" + applicationName)
      
      let zelle = Zelle(
          applicationName : applicationName,
          baseURL: baseUrl,
          institutionId: institutionId,
          product: product,
          ssoKey: ssoKey,
          fi_callback: fi_callback,
          loaderData: loaderData! as? [String : String],
          parameters: parameters! as? [String : String]
      )

      let bridge: Bridge = {
      Bridge(
          config: zelle,
          viewController: self
      )
  }()

      let zelleFrame = CGRect(x:0, y:0, width:view.frame.width, height:view.frame.height) //desired location
      let zelleView = bridge.view(frame: zelleFrame)

    //  let zelleView = bridge.popup(anchor: self.view)

      view.addSubview(zelleView)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
