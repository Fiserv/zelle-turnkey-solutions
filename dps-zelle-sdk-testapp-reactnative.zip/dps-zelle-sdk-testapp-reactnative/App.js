import React from 'react';
import Zelle from './Zelle';

export default function App() {
  return (
    <Zelle/>
  );
}