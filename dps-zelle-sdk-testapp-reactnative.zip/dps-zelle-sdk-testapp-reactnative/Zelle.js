import React, { Component } from 'react';
import { Button, Keyboard, Platform, StyleSheet, Text, TextInput, View, NativeModules} from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { NativeEventEmitter, DeviceEventEmitter } from 'react-native';

const {MyModule} = NativeModules;
const myModduleEvent = new NativeEventEmitter(MyModule);

export default class Zelle extends Component {

  appnameInputRef = React.createRef();
  baseurlInputRef = React.createRef();
  institutionidInputRef = React.createRef();
  productInputRef = React.createRef();
  ssokeyInputRef = React.createRef();
  scrollViewRef = React.createRef();

  constructor(props) {
    super(props);
    this.state = {
        appname: '',
        baseurl: '',
        institutionid: '',
        product: '',
        ssokey: '',
        showAppNameError: false,
        showBaseUrlError: false,
        showInstitutionIdError: false,
        showProductError: false,
        showSsoKeyError: false,
    };
    this.submitPressed = this.submitPressed.bind(this);
  }

  inputs = () => {
    return [
      this.appnameInputRef,
      this.baseurlInputRef,
      this.institutionidInputRef,
      this.productInputRef,
      this.ssokeyInputRef,
    ];
  };

  editNextInput = () => {
    //console.log("editNextInput")
    const activeIndex = this.getActiveInputIndex();
    if (activeIndex === -1) {
        return;
    }

    const nextIndex = activeIndex + 1;
    if (nextIndex < this.inputs().length && this.inputs()[nextIndex].current != null) {
        this.setFocus(this.inputs()[nextIndex], true);
    } else {
        this.finishEditing();
    }
  }

  onInputFocus = () => {
    this.setState({
        activeIndex: this.getActiveInputIndex(),
    });
  }

  onChangeInputHandler = (name, value) => {
    this.setState({
        [name]: value,
    });
  }

  getActiveInputIndex = () => {
    const activeIndex = this.inputs().findIndex((input) => {
        if (input.current == null) {
            return false;
        }
        //console.log("input: ", input);
        return input.current.isFocused();
    });
    //console.log("activeIndex: ", activeIndex);
    return activeIndex;
  }

  finishEditing = () => {
    const activeIndex = this.getActiveInputIndex();
    if (activeIndex === -1) {
        return;
    }
    this.setFocus(this.inputs()[activeIndex], false);
  }

  setFocus(textInputRef, shouldFocus) {
    if (shouldFocus) {
        setTimeout(() => {
            textInputRef.current.focus();
        }, 100);
    } else {
        textInputRef.current.blur();
    }
  }

  componentDidMount(){
    this.subscription = myModduleEvent.addListener("getValue", event => {
      console.log("new event emitter2=====>",event.data);
    });
    this.subscription = myModduleEvent.addListener("sessionTimeout", event => {
      console.log("new event emitter2=====>",event.data);
    });
  }

  componentWillUnmount(){
    this.subscription.remove();
  }

  

  submitPressed() {
    this.setState({
        showAppNameError: this.state.appname.length < 1,
        showBaseUrlError: this.state.baseurl.length < 4,
        showInstitutionIdError: this.state.institutionid.length < 1,
        showProductError: this.state.product.length < 1,
        showSsoKeyError: this.state.ssokey.length < 1,
    });
    //console.log("submitPressed this.state: ", this.state);
    Keyboard.dismiss();
    if(this.state.baseurl.length > 4){
      var pd = {};
      var parameter = {};
      parameter.param1 = "param1_value";
      parameter.param2 = "param2_value";
      parameter.param3 = "param3_value";
      var contact = {};
      contact.title = "Prominent Disclosure title from react native";
      contact.message = "Prominent Disclosure message from react native";
      var camera = {};
      camera.title = "PD Camera";
      camera.message = "PD Camera";
      var gallery = {};
      gallery.title = "PD Gallery";
      gallery.message = "PD Gallery";
      pd.pd_contact = c;
      pd.pd_camera = d;
      pd.pd_gallery = e;
      var fi_callback = true
      var loaderData = {}
      loaderData.loaderColor = "";
      loaderData.bgColor = "";
      NativeModules.MyModule.NavigateToZelle(this.state.appname, this.state.baseurl, this.state.institutionid, this.state.product, this.state.ssokey, fi_callback, loaderData, parameter, pd);

    }

  }


  nameOfJsMethod(message) {
    alert(message);
  }

  render() {
    return (
        <KeyboardAwareScrollView
          style={styles.container}
          contentOffset={{ x: 0, y: 24 }}
          ref={this._scrollViewRef}
          scrollEventThrottle={16}
          contentContainerStyle={{ paddingTop: 24 }}
          contentInsetAdjustmentBehavior="always"
          keyboardShouldPersistTaps="handled"
          keyboardDismissMode="on-drag"
          enableOnAndroid={true}
          extraHeight={32}
          extraScrollHeight={Platform.OS == "android" ? 32 : 0}
          enableResetScrollToCoords={false}
          onKeyboardDidShow={this._keyboardDidShowHandler}
        >
            <View style={styles.container}>

                <Text style={styles.header}>Launch Zelle</Text>

                <View style={styles.inputTextWrapper}>
                    <TextInput
                        placeholder="Enter application name"
                        style={styles.textInput}
                        returnKeyType="next"
                        onSubmitEditing={this.editNextInput}
                        onFocus={this.onInputFocus}
                        onChangeText={val => this.onChangeInputHandler('appname', val)}
                        ref={this.appnameInputRef}
                    />
                    {this.state.showAppNameError &&
                        <Text style={styles.errorText}>Please enter your app name.</Text>
                    }
                </View>

                <View style={styles.inputTextWrapper}>
                    <TextInput
                        placeholder="Enter the base url"
                        style={styles.textInput}
                        returnKeyType="next"
                        onSubmitEditing={this.editNextInput}
                        onFocus={this.onInputFocus}
                        onChangeText={val => this.onChangeInputHandler('baseurl', val)}
                        ref={this.baseurlInputRef}
                    />
                    {this.state.showBaseUrlError &&
                        <Text style={styles.errorText}>Please enter a base url.</Text>
                    }
                </View>

                <View style={styles.inputTextWrapper}>
                    <TextInput
                        placeholder="Enter the institution id"
                        style={styles.textInput}
                        returnKeyType="next"
                        onSubmitEditing={this.editNextInput}
                        onFocus={this.onInputFocus}
                        onChangeText={val => this.onChangeInputHandler('institutionid', val)}
                        ref={this.institutionidInputRef}
                    />
                    {this.state.showInstitutionIdError &&
                        <Text style={styles.errorText}>Please enter your institution id.</Text>
                    }
                </View>

                <View style={styles.inputTextWrapper}>
                    <TextInput
                        placeholder="Enter the product"
                        style={styles.textInput}
                        returnKeyType="next"
                        onSubmitEditing={this.editNextInput}
                        onFocus={this.onInputFocus}
                        onChangeText={val => this.onChangeInputHandler('product', val)}
                        ref={this.productInputRef}
                      />
                    {this.state.showProductError &&
                        <Text style={styles.errorText}>Please enter your product.</Text>
                    }
                </View>

                <View style={styles.inputTextWrapper}>
                    <TextInput
                        placeholder="Enter the SSO key"
                        style={styles.textInput}
                        returnKeyType="next"
                        onSubmitEditing={this.editNextInput}
                        onFocus={this.onInputFocus}
                        onChangeText={val => this.onChangeInputHandler('ssokey', val)}
                        ref={this.ssokeyInputRef}
                    />
                    {this.state.showSsoKeyError &&
                        <Text style={styles.errorText}>Please enter your SSO key.</Text>
                    }
                </View>

                <View style={styles.btnContainer}>
                  <Button title="Submit" onPress={this.submitPressed} />
                </View>

            </View>
        </KeyboardAwareScrollView>
      );
  }
}

const styles = StyleSheet.create({
    container: {
      flex: 1,
      padding: 16,
      paddingBottom: 100,
    },
    header: {
      fontSize: 36,
      padding: 24,
      margin: 12,
      textAlign: "center",
    },
    inputTextWrapper: {
      marginBottom: 24,
    },
    textInput: {
      height: 40,
      borderColor: "#000000",
      borderBottomWidth: 1,
      paddingRight: 30,
    },
    errorText: {
      color: 'red',
      fontSize: 10,
    },
    btnContainer: {
      backgroundColor: "white",
      marginTop:36,
    }
  });