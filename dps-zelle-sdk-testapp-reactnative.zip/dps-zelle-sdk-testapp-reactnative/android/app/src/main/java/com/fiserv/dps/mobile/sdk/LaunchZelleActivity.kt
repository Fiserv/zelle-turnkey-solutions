package com.fiserv.dps.mobile.sdk

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.fiserv.dps.mobile.sdk.bridge.controller.Bridge
import com.fiserv.dps.mobile.sdk.bridge.model.Zelle


class LaunchZelleActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_launch_zelle)

        val appName = intent.getStringExtra("appName").toString()
        val baseUrl = intent.getStringExtra("baseURL").toString()
        val instId = intent.getStringExtra("instId").toString()
        val product = intent.getStringExtra("product").toString()
        val ssoKey = intent.getStringExtra("ssoKey").toString()
        val fi_callback: Boolean = intent.extras?.getBoolean("fi_callback") ?: false
        val loaderData: HashMap<String, String> = intent.getSerializableExtra("loaderData") as HashMap<String, String>
        val parameters: HashMap<String, String> = intent.getSerializableExtra("parameters") as HashMap<String, String>
        val pd: Map<String, Map<String, String>> = intent.getSerializableExtra("pd") as Map<String, Map<String, String>>



        Log.d("Data from activity ======>", "$parameters  $pd")

        val zelle = Zelle(
            applicationName = appName,
            baseURL = baseUrl,
            institutionId = instId,
            product = product,
            ssoKey = ssoKey,
            fi_callback = fi_callback,
            loaderData = loaderData,
            appData = pd,
            parameters = parameters,

        )
        val bridge = Bridge(this, zelle)
        zelle.preCacheContacts = true
        val view = bridge.view()
        supportFragmentManager.beginTransaction().replace(R.id.frame_layout, view).commit()

    }

}