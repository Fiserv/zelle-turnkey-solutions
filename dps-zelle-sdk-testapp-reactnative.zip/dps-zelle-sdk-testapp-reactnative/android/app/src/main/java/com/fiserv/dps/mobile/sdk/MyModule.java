package com.fiserv.dps.mobile.sdk;

import android.content.Intent;
import android.util.Log;

import androidx.annotation.NonNull;

import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;
import com.fiserv.dps.mobile.sdk.bridge.controller.Bridge;
import com.fiserv.dps.mobile.sdk.interfaces.GenericTag;

public class MyModule extends ReactContextBaseJavaModule implements GenericTag {

    ReactApplicationContext context = getReactApplicationContext();

    public MyModule(@NonNull ReactApplicationContext reactContext) {
        super(reactContext);
    }

    Boolean fi_callback = false;
    @NonNull
    @Override
    public String getName() {
        return "MyModule";
    }

    @ReactMethod
    public void NavigateToZelle(String appName, String baseURL, String instId, String product, String ssoKey, Boolean fi_callback, ReadableMap loaderData,ReadableMap parameters, ReadableMap pd){

        Bridge.genericTag = this;
        this.fi_callback = fi_callback;
        Intent intent = new Intent(context, LaunchZelleActivity.class);
        if(intent.resolveActivity(context.getPackageManager()) != null){
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            Log.d("Data from ui ======>", parameters.toHashMap()+"  "+pd.toHashMap());
            intent.putExtra("appName", appName);
            intent.putExtra("baseURL", baseURL);
            intent.putExtra("instId", instId);
            intent.putExtra("product", product);
            intent.putExtra("ssoKey", ssoKey);
            intent.putExtra("fi_callback", this.fi_callback);
            intent.putExtra("loaderData", loaderData.toHashMap());
            intent.putExtra("parameters", parameters.toHashMap());
            intent.putExtra("pd", pd.toHashMap());
            context.startActivity(intent);
            
        }

    }

    @Override
    public void sessionTag(@NonNull String s) {
        if (!s.equals("")){
            try {
                WritableMap event = Arguments.createMap();
                event.putString("data", s);
                context.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)
                        .emit("sessionTimeout", event);

            } catch (Exception e){
                Log.e("ReactEmitter", "==============>Caught Exception: " + e.getMessage());
            }

        }
    }

    @Override
    public void getValue(@NonNull String s) {
        Log.e("ReactEmitter", s);
        if (!s.equals("")){
            try {
                WritableMap event = Arguments.createMap();
                event.putString("data", s);
                context.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)
                        .emit("getValue",  event);

            } catch (Exception e){
                Log.e("ReactEmitter", "==============>Caught Exception: " + e.getMessage());
            }

        }
    }
}
